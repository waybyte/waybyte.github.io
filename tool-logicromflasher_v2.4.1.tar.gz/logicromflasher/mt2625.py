############################################################################
#
# Copyright (c) 2021 WAYBYTE Solutions
#
# LOGICROM FlashTool For MTK NBIoT modules in Python
#
# Based on MT2625 Flash Utility By Georgi Angelov
#
############################################################################
#
# Mediatek MT2625 Flash Utility ver 2.01
#
#   Copyright (C) 2019 Georgi Angelov. All rights reserved.
#   Author: Georgi Angelov <the.wizarda@gmail.com> WizIO
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
#
# 1. Redistributions of source code must retain the above copyright
#    notice, this list of conditions and the following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright
#    notice, this list of conditions and the following disclaimer in
#    the documentation and/or other materials provided with the
#    distribution.
# 3. Neither the name WizIO nor the names of its contributors may be
#    used to endorse or promote products derived from this software
#    without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
# COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
# OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
# AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.
#
############################################################################
# Compatable:
#   Python 2 & 3
# Dependency:
#   https://github.com/pyserial/pyserial/tree/master/serial
############################################################################

from __future__ import print_function
import os
import sys
import struct
import time
import os.path
from os.path import join
from serial import Serial
from serial import serialutil as serialutil
from binascii import hexlify

############################################################################

PYTHON2 = sys.version_info[0] < 3  # True if on pre-Python 3

if PYTHON2:
    pass
else:
    def xrange(*args, **kwargs):
        return iter(range(*args, **kwargs))

############################################################################

DEBUG = False

CONF = b'\x69'
STOP = b'\x96'
ACK = b'\x5A'
NACK = b'\xA5'
CMD_READ16 = b'\xD0'
CMD_READ32 = b'\xD1'
CMD_WRITE16 = b'\xD2'
CMD_WRITE32 = b'\xD4'
CMD_JUMP_DA = b'\xD5'
CMD_SEND_DA = b'\xD7'
CMD_SEND_EPP = b'\xD9'
DA_READ = b'\xD6'
DA_FINISH = b'\xD9'
DA_NWDM_INFO = b'\x80'
DA_P2A = b'\xB0'
DA_A2P = b'\xB1'
DA_WRITE_ADDR = b'\xB2'

UART_BAUD_921600 = b'\x01'
UART_BAUD_460800 = b'\x02'
UART_BAUD_230400 = b'\x03'
UART_BAUD_115200 = b'\x04'

def ERROR(message):
    print("\nERROR: {}".format(message))
    time.sleep(0.1)
    exit(2)


def ASSERT(flag, message):
    if flag == False:
        ERROR(message)


def hexs(s):
    if False == PYTHON2:
        if str == type(s):
            s = bytearray(s, 'utf-8')
    return hexlify(s).decode("ascii").upper()


def rem_zero(str):
    r = ""
    for i in range(len(str)):
        if i % 2 != 0:
            r = r + str[i]
    return r


def checksum(data, c=0):
    for i in range(len(data)):
        if PYTHON2:
            c += ord(data[i])  # py2
        else:
            c += data[i]  # py3
    return c


class progressbar:
    def __init__(self, prefix="", total=100, size=50, f=sys.stdout):
        self.reset(prefix, total, size, f)

    def reset(self, prefix="", total=100, size=50, f=sys.stdout):
        self.prefix = prefix
        self.total = total
        self.count = 0
        self.size = size
        self.file = f
        self.isatty = f.isatty()
        self.hash = -1

    def update(self, j):
        self.count += j
        x = int(self.size * self.count / self.total)
        per = int(self.count * 100 / self.total)
        if self.isatty:
            self.file.write("%s [%s%s] %i%%\r" %
                            (self.prefix, "#"*x, "."*(self.size-x), per))
        elif self.hash != x:
            if self.hash == -1:
                self.hash = x
                self.file.write("%s\n|%s" % (self.prefix, "#"*x))
            else:
                self.file.write("%s" % ("#"*(x-self.hash)))
                self.hash = x
        self.file.flush()

    def end(self):
        if not self.isatty:
            self.file.write("| 100%\n")
        else:
            self.file.write("\n")
        self.file.flush()


############################################################################

class MT2625:
    DA = {
        "0x8100.0": {
            "1": {"offset": 0x00000, "size": 0X00CB5, "address": 0x04015000},
            "2": {"offset": 0x00CB5, "size": 0X0BCA4, "address": 0x04001000},
            "3": {"offset": 0x0C959, "size": 48}
        },
        "0x8300.0": {
            "1": {"offset": 0x0D019, "size": 0X00941, "address": 0x04015000},
            "2": {"offset": 0x0D95A, "size": 0X0A334, "address": 0x04001000},
            "3": {"offset": 0x17C8E, "size": 0x00024}
        }
    }

    def __init__(self):
        self.dir = os.path.dirname(os.path.realpath(__file__))
        self.nvdm_address = 0
        self.nvdm_length = 0

    def DBG(self, s):
        if self.debug:
            print(s)

    def open(self):
        try:
            self.s = Serial(self.port, 115200)
        except serialutil.SerialException as ex:
            ERROR(ex)

    def close(self):
        try:
            self.s.close()
        except serialutil.SerialException as ex:
            ERROR(ex)

    def read(self, read_size=0):
        r = ""
        if read_size > 0:
            r = self.s.read(read_size)
            if self.debug:
                print("<-- {}".format(hexs(r)))
        return r

    def send(self, data, read_size=0):  # py3
        r = ""
        if len(data):
            if self.debug:
                print("--> {}".format(hexs(data)))
            if True == PYTHON2:
                self.s.write(data)
            elif str == type(data):
                self.s.write(bytearray(data, 'utf-8'))
            else:
                self.s.write(data)
        return self.read(read_size)

    def cmd(self, cmd, read_size=0):
        r = ""
        size = len(cmd)
        if size > 0:
            ASSERT(self.send(cmd, size) == cmd, "CMD Echo")
        return self.read(read_size)

    def da_read16(self, addr, sz=1):
        r = self.cmd(CMD_READ16 + struct.pack(">II", addr, sz), (sz*2)+4)
        return struct.unpack(">" + sz * 'HHH', r)

    def da_write16(self, addr, val):
        r = self.cmd(CMD_WRITE16 + struct.pack(">II", addr, 1), 2)
        r = self.cmd(struct.pack(">H", val), 2)

    def da_read(self, address, size=4096, block=4096):
        self.DBG("READ: %08X | %08X | %08X" % (address, size, block))
        ASSERT(self.send(DA_READ + struct.pack(">III", address,
                                               size, block), 1) == ACK, "da_read ACK Answer")

    def get_da(self, offset, size):
        self.fd.seek(offset)
        data = self.fd.read(size)
        return data

    def loadBootLoader(self, fname=""):
        fname = join(self.dir, fname)
        ASSERT(os.path.isfile(fname) == True,
               "Missing download agent: " + fname)
        self.fd = open(fname, "rb")

    def connect(self, timeout=30):
        # Boot
        self.s.timeout = 0.02  # maybe must more
        start = time.time()
        print("Waiting module for POWER-ON or RESET...")
        sys.stdout.flush()
        while True:
            self.s.write(b"\xA0")
            if self.s.read(1) == b"\x5F":
                self.s.write(b"\x0A\x50\x05")
                r = self.s.read(3)
                if r == b"\xF5\xAF\xFA":
                    break
                else:
                    ERROR("BOOT")
            if ((time.time() - start) > timeout):
                ERROR("Timeout")
        self.s.timeout = 1.0
        # INIT
        # WDT_Base = 0xA2090000 , WDT_Disable = 0x11
        self.da_write16(0xA2090000, 0x11)
        # GET CHIP INFO
        self.chip_0 = self.da_read16(0x80000000)
        self.chip_4 = self.da_read16(0x80000004)
        BB_CPU_ID = self.da_read16(0x80000008)[1]
        if BB_CPU_ID != 0x2625:
            ERROR("Flasher does not support this SoC: %04x" % BB_CPU_ID)
        self.chip_ver = self.da_read16(0x8000000C)[1]
        if self.chip_ver != 0x8300 and self.chip_ver != 0x8100:
            ERROR("Unknown chipset version %04X" % self.chip_ver)
        self.chip = hex(self.chip_ver) + ".0"  # or ".1"
        self.loadBootLoader("mt2625_da.bin")

    def da_changebaud(self, baud=921600):
        speed_table = {
            921600: UART_BAUD_921600,
            460800: UART_BAUD_460800,
            230400: UART_BAUD_230400,
            115200: UART_BAUD_115200
        }

        self.s.write(ACK)
        self.s.read(2)
        self.s.write(ACK + speed_table.get(baud, UART_BAUD_921600))
        self.s.read(2)
        self.s.write(ACK)
        self.s.read(2)
        self.s.write(ACK + ACK)
        time.sleep(0.1)
        # SET BAUDRATE
        self.s.baudrate = baud
        self.s.write(CONF)
        ASSERT(self.s.read(1) == CONF, "Uart brg CONF")
        self.s.write(ACK)
        ASSERT(self.s.read(1) == ACK, "Uart brg ACK")
        # SYNC UART # py3
        for i in xrange(15, 255, 15):
            wr = struct.pack(b'<B', i)
            self.s.write(wr)
            rd = self.s.read(1)
            ASSERT(rd == wr, "DA SPEED sync fail")
        ASSERT(self.s.read(2) == b"\0\0", "Uart test 1")
        self.s.write(ACK)
        ASSERT(self.s.read(2) == b"\0\0", "Uart test 2")
        self.s.write(ACK)
        ASSERT(self.s.read(4) == b"\0\0\0\0", "Uart test 3")
        self.s.write(ACK)
        ASSERT(self.s.read(6) == b"\0\0\0\0\0\0", "Uart test 4")
        self.s.reset_input_buffer()
        self.s.reset_output_buffer()

    def da_read_buffer(self, block=4096):
        data = self.s.read(block)
        crc = self.read(2)  # check sum
        self.s.write(ACK)
        return data, crc

    def da_write_address(self, address, size, block=4096):
        self.DBG("WRITE: %08X | %08X | %08X" % (address, size, block))
        ASSERT(self.send(DA_WRITE_ADDR + struct.pack(">III", address,
                                                     size, block), 2) == ACK + ACK, "da_write_address ACK Answer")

    def da_write_buffer(self, data, cs):
        c = checksum(data)
        self.s.write(data)
        self.send(struct.pack(">H", c & 0xFFFF))
        if self.read(1) != CONF:
            self.read(4)
            ASSERT(False, "da_write_buffer CRC")  # A5 00 00 0B F5
        return cs + c

    def da_write_all(self, data, size, block=4096):
        cs = 0
        for i in xrange(0, size, block):
            self.DBG("--> data[{}]".format(block))
            d = data[:block]
            data = data[block:]
            cs = self.da_write_buffer(d, cs)
            self.pb.update(block)
        ASSERT(self.read(1) == ACK, "da_write_all ack")
        ASSERT(self.send(struct.pack(">H", cs & 0xFFFF), 1)
               == ACK, "da_write_all CRC")
        ASSERT(self.send("\xA5", 1) == ACK, "da_write_all end")

    def da_p2a(self, page):  # page to address
        r = self.send(DA_P2A + struct.pack(">I", page), 5)  # res = 08292000-5A
        ASSERT(r[4] == ACK[0], "Page to address")
        return struct.unpack(">I", r[:4])[0]

    def da_a2p(self, address):  # address to page
        r = self.send(DA_A2P + struct.pack(">I", address),
                      5)  # res = 00000292-5A
        ASSERT(r[4] == ACK[0], "Address to page")
        return struct.unpack(">I", r[:4])[0]

    def get_da_info(self, flashid, offset, size):
        self.fd.seek(offset)
        while size > 0:
            data = self.fd.read(36)
            if flashid in data:
                return data
            size -= 1
        ERROR("Flash not supported")

    def find_imei(self, data):
        global imei
        while 'Enas\0IMEI' in data:
            n = data.find('Enas\0IMEI')
            if n > -1:
                imei = hexs(data[n+10: n+26])
                imei = rem_zero(imei)
                #self.DBG(imei)
            data = data[n+1:]

    def backupNVDM(self, fname=""):
        global imei
        imei = ''
        ASSERT(self.nvdm_address != 0 or self.nvdm_length != 0, "NVDM Params")
        self.da_read(self.nvdm_address, self.nvdm_length)
        if fname == "":
            fname = join(self.dir, "nvdm.bin")
        f = open(fname, 'wb')
        for i in xrange(self.nvdm_address, self.nvdm_address + self.nvdm_length, 4096):
            data, crc = self.da_read_buffer(4096)
            f.write(data)
            self.find_imei(data)
        f.close()
        name = fname.replace(".bin", '_'+imei+".dat")
        try:
            if os.path.exists(name):
                os.remove(name)
            os.rename(fname, name)
            print('NVDM File: ' + name)
        except OSError:
            print('NVDM File: ' + fname)

    def da_start(self, nvdm=0):
        # Begin
        ASSERT(self.chip in self.DA, "Unknown module: {}".format(self.chip))
        self.s.timeout = 1
        # Setup progress bar
        da_total_sz = 0
        for da_part in self.DA[self.chip]:
            da_total_sz += self.DA[self.chip][da_part]['size']
        self.pb = progressbar("Download DA", da_total_sz)
        self.pb.update(0)
        # DA_1
        offset = self.DA[self.chip]["1"]["offset"]
        size = self.DA[self.chip]["1"]["size"]
        address = self.DA[self.chip]["1"]["address"]
        data = self.get_da(offset, size)
        ASSERT(self.cmd(CMD_SEND_EPP + struct.pack(">IIII", address,
                                                   size, 0x04002000, 0x00001000), 2) == b"\0\0", "CMD_SEND_EPP")
        while data:
            self.pb.update(self.s.write(data[:1024]))
            data = data[1024:]
        if self.chip == "0x8300.0":
            ASSERT(self.cmd("", 10) == b"\x70\x22\0\0\0\0\0\0\0\0", "EPP Answer")
        else:
            ASSERT(self.cmd("", 10) == b"\x1D\x3D\0\0\0\0\0\0\0\0", "EPP Answer")
        self.da_changebaud()
        # DA_2
        offset = self.DA[self.chip]["2"]["offset"]
        size = self.DA[self.chip]["2"]["size"]
        address = self.DA[self.chip]["2"]["address"]
        data = self.get_da(offset, size)
        ASSERT(self.cmd(CMD_SEND_DA + struct.pack(">III", address,
                                                  size, 0x00000000), 2) == b"\0\0", "CMD_SEND_DA")
        while data:
            self.pb.update(self.s.write(data[:4096]))
            data = data[4096:]
        r = self.read(4)  # checksum D6AE0000 XOR
        # JUMP DA
        ASSERT(self.cmd(CMD_JUMP_DA + struct.pack(">I", address), 2)
               == b"\0\0", "CMD_JUMP_DA")  # D5-04001000
        r = self.read(1)                        # <-- C0
        r = self.send(b"\x3F\xF3\xC0\x0C", 4)   # <-- 0C3FF35A - Magic ?
        r = self.send(b"\x00\x00", 2)           # <-- 6969
        flashID = self.send(ACK, 6)             # <-- 00C200250036 - FlashID
        flashData = self.get_da_info(
            flashID, self.DA[self.chip]["3"]["offset"], self.DA[self.chip]["3"]["size"])
        r = self.send(b"\x24", 1)               # <-- 5A
        self.send(flashData)                    # ????
        self.pb.update(len(flashData))
        self.pb.end()
        flashInfo = self.s.read(80)           # unknow len [67]
        i = len(flashInfo) - 1
        # py2 Z = Z .... py3 90 = b'Z'
        ASSERT(flashInfo[i] == ACK[0], "Flash info")
        self.send(ACK)
        if nvdm > 0:
            self.send(DA_NWDM_INFO)
            for i in range(256):
                if self.s.read(1) == ACK:
                    r = self.read(4)
                    self.nvdm_address = struct.unpack(">I", r)[0]
                    r = self.read(4)
                    self.nvdm_length = struct.unpack(">I", r)[0]
                    self.DBG('NVDM Address: 0x%08X' % self.nvdm_address)
                    self.DBG('NVDM Length : 0x%08X' % self.nvdm_length)
                    return
            ERROR("NWDM Info")

    def openApplication(self, check=True):
        i = 0
        tmp_ftype = []
        tmp_addr = []
        tmp_size = []
        tmp_app_data = []

        for firmware in self.firmware:
            firmware.seek(0x18)
            tmp_ftype.append(struct.unpack("<H", firmware.read(2))[0])
            firmware.seek(0x1c)
            tmp_addr.append(struct.unpack("<I", firmware.read(4))[0])
            tmp_size.append(struct.unpack("<I", firmware.read(4))[0])
            firmware.seek(0)
            tmp_app_data.append(firmware.read())
            app_size = len(tmp_app_data[i])
            ASSERT(tmp_size[i] == app_size, "APP: Size mismatch")
            if app_size < 0x40:
                ERROR("APP: Invalid size.")
            if check == True:
                if tmp_app_data[i][:3].decode() != "MMM":
                    ERROR("APP: Invalid header 'MMM' expected.")
                if tmp_app_data[i][8:17].decode() != "FILE_INFO":
                    ERROR("APP: Invalid header 'FILE_INFO' expected.")
            i += 1

        # Sort by address
        addr = tmp_addr.copy()
        size = []
        ftype = []
        app_data = []
        addr.sort()
        for start_addr in addr:
            i = 0
            for appaddr in tmp_addr:
                if appaddr == start_addr:
                    size.append(tmp_size[i])
                    ftype.append(tmp_ftype[i])
                    app_data.append(tmp_app_data[i])
                    break
                i += 1

        return app_data, addr, size, ftype

    def uploadApplication(self):
        # TODO: Only one firmware file supported as of now.
        # Will use the first file only.

        app_address = self.app_address[0]
        app_data = self.app_data[0]
        app_size = self.app_size[0]

        first_page = self.da_a2p(app_address)
        first_address = self.da_p2a(first_page)
        last_page = self.da_a2p(app_address + app_size)
        last_address = self.da_p2a(last_page + 1)
        rem_first = app_address - first_address
        rem_last = last_address - (app_address + app_size)
        self.DBG("APP  SIZE: %08X" % app_size)
        self.DBG("APP-B ADR: %08X" % app_address)
        self.DBG("APP-E ADR: %08X" % (app_address + app_size))
        self.DBG("FIRST ADR: %08X" % first_address)
        self.DBG("FIRST REM: %08X" % rem_first)
        self.DBG("LAST  ADR: %08X" % last_address)
        self.DBG("LAST  REM: %08X" % rem_last)
        final_bin = ''
        if rem_first > 0:  # REPLACE FIRST PAGE
            self.da_read(first_address)
            data, crc = self.da_read_buffer()
            ASSERT(len(data) == 4096, "First page data length mismatch")
            final_bin = data[0: rem_first]
            final_bin += app_data
            self.DBG("REPLACED FIRST PAGE")
        else:
            final_bin = app_data
        if rem_last > 0:  # REPLACE LAST PAGE
            self.da_read(last_address)
            data, crc = self.da_read_buffer()
            ASSERT(len(data) == 4096, "Last page data length mismatch")
            final_bin += data[-rem_last:]
            self.DBG("REPLACED LAST PAGE")
        # WRITE
        self.s.timeout = 1.0
        size = len(final_bin)
        self.pb.reset("Download Firmware", size)
        self.DBG("BIN SIZE: %08X" % size)
        self.da_write_address(first_address, size)
        self.da_write_all(final_bin, size)
        self.pb.end()

    def da_finish(self):
        self.s.write(DA_FINISH + b'\x00')
        ASSERT(self.s.read(1) == b'\x5A', "Finish")

    def upload_app(self):
        self.app_data, self.app_address, self.app_size, self.app_type = self.openApplication(
            True)
        self.open()
        self.connect()
        self.da_start()
        self.uploadApplication()
        self.da_finish()
        self.close()
        #TODO: NVDM backup

############################################################################

def mt2625_flasher(opts):
    flasher = MT2625()
    flasher.port = opts.port
    flasher.baud = opts.baud
    flasher.opt = opts.opt
    flasher.no_reset = opts.no_reset
    flasher.firmware = [open(firmware, "rb") for firmware in opts.firmware]
    flasher.debug = opts.debug
    return flasher
