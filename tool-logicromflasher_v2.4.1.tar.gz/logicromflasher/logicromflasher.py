############################################################################
#
# Copyright (c) 2021 WAYBYTE Solutions
#
# LOGICROM Flash Tool for 4G LTE, GSM and NBIoT modules in Python
#
# SPDX-License-Identifier: MIT
#
############################################################################
# Dependency:
#      https://github.com/pyserial/pyserial/tree/master/serial
############################################################################

import sys
import signal
from argparse import ArgumentParser, RawTextHelpFormatter, ArgumentDefaultsHelpFormatter
from mt6261 import mt6261_flasher
from mt2625 import mt2625_flasher
from rda8910 import rda8910_flasher

APP_VER="0.5.0"

DEBUG = False

class Flasher:
    def __init__(self):
        return

    def run(self):
        if self.mcu == "RDA8910":
            flasher = rda8910_flasher(self)
        elif self.mcu == "MT2625":
            flasher = mt2625_flasher(self)
        else:
            flasher = mt6261_flasher(self)
        flasher.upload_app()

class ArgsFormatter(ArgumentDefaultsHelpFormatter, RawTextHelpFormatter):
    pass

def signal_handler(sig, frame):
    print("""\nFirmware download interrupted\nOperation has been stopped!\n\nUnable to flash device""")
    sys.exit(0)

if __name__ == '__main__':
    print("\n(c) 2021 WAYBYTE Solutions\nLogicrom Flash Tool v" + APP_VER +"\n")
    signal.signal(signal.SIGINT, signal_handler)

    flasher = Flasher()
    parser = ArgumentParser(description='LOGICROM Flash Tool', formatter_class=ArgsFormatter)
    parser.add_argument("-p", "--port", help="Serial port for flashing.")
    parser.add_argument("-b", "--baud", type=int, default=460800, help="Serial port baudrate.")
    parser.add_argument("-o", "--opt", type=int, default=1,
            help="""Flash Options:
    0: Download Firmware and Format
    1: Download Firmware only""")
    parser.add_argument("-n", "--no-reset", help="Do not reset after flashing", action='store_true')
    parser.add_argument("firmware", nargs="+", help="""For MCU Type RDA8910:
    [FDL1_addr] [FDL1_file] [FDL2_addr] [FDL2_file] [APP_addr] [APPIMG_file]

    For Other MCU type:
    [Firmware_file]
    """)
    parser.add_argument("-v", "--version", action="version", version="Logicrom Flash Tool v" + APP_VER)
    parser.add_argument("-m", "--mcu", default="MT6261", help="""MCU Select:
    RDA8910: 4G LTE Cat.1 Modules (N58, N716, EC600, EC200 etc.)
    MT6261/MT2503: MCU type for GSM modules (MC20, MC60, SIM868 etc.)
    MT2625: MCU type for NBIoT module (BC20/BC66)""")
    parser.parse_args(namespace=flasher)
    flasher.mcu = flasher.mcu.upper()
    if flasher.mcu != "RDA8910" and flasher.port == None:
        parser.error("-p/--port is required for MCU Type: " + flasher.mcu + "\n")
        print("Selected Port: %s" % flasher.port)
    elif flasher.mcu == "RDA8910" and len(flasher.firmware) != 6:
        parser.error("Firmware argument format for " + flasher.mcu +
                     "\n[FDL1_addr] [FDL1_file] [FDL2_addr] [FDL2_file] [APP_addr] [APPIMG_file]\n")

    print("\nPress ctrl+c to stop and exit")
    flasher.debug = DEBUG
    flasher.run()
