OneWire API
===========

OneWire driver optimized for GSM module.

.. include:: /inc/onewire.inc

