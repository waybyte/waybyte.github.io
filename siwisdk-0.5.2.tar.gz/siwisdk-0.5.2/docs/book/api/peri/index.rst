Peripherals
===========

.. toctree::
   :maxdepth: 1

   ADC <adc>
   GPIO <gpio>
   I2C <i2c>
   SPI <spi>
   PWM <pwm>
   UART <uart>
   USB <usb>
   Bluetooth <bluetooth>
   GPS <gps>
