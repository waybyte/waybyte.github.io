System Call Support
===================

List of supported system calls.

*TODO: Add list functions supported*

