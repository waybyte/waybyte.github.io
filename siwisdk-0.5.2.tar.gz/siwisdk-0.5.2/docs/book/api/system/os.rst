OS API
======

API Reference
-------------

.. include:: /inc/os_api.inc

