SIWI Timer API
==============

API Reference
-------------

.. include:: /inc/timer.inc

