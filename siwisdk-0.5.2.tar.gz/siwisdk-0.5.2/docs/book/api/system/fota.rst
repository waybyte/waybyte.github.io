Firmware OTA API
================

Firmare over-the-air update API.

API Reference
-------------

.. .. include:: /inc/fota.inc

