Parmeter Storage API
====================

Parameter storage library can be used to store system configuration. API uses
internal flash for parameter storage.

API Reference
-------------

.. include:: /inc/param.inc

