AES Encryption API
==================

.. include:: /inc/aes.inc
