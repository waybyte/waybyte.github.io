Network API
===========

.. toctree::
   :maxdepth: 1

   GSM & GPRS API <gsm_gprs>
   RAW Socket API <socket>
   BSD Socket API <bsd_socket>
   Radio Interface Layer - RIL <ril>
