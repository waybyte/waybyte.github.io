Radio Interface Layer - RIL
===========================

.. include:: /inc/ril.inc

