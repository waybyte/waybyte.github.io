BSD Socket API
==============

.. include:: /inc/socket.inc

