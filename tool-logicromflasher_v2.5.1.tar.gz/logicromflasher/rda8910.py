############################################################################
#
# Copyright (c) Waybyte Solutions
#
# LOGICROM Flash Tool for 4G LTE, GSM and NBIoT modules in Python
#
# SPDX-License-Identifier: MIT
#
############################################################################

from time import *
from binascii import hexlify
from serial import Serial
from serial.tools import list_ports
from serial import serialutil as serialutil
from struct import *
from sys import stdout, exit
from os.path import getsize

CMD_PDL1_SEARCH = 0x0c
CMD_PDL1_DLFDL1 = 0x11
CMD_PDL1_WRDATA = 0x80c
CMD_PDL1_WRDATA_LAST = 0x28c
CMD_PDL1_FINISH = 0x10

CMD_FDL1_NOP = 0x0
CMD_FDL1_SETBAUD = 0x09
CMD_FDL1_WRSTART = 0x01
CMD_FDL1_WRDATA = 0x02
CMD_FDL1_WRFINISH = 0x03
CMD_FDL1_EXEC = 0x04
CMD_FDL1_RESET = 0x05

def ERROR(message):
    print("\nERROR: {}\n".format(message))
    exit(2)


def ASSERT(flag, message):
    if flag == False:
        ERROR(message)


def hexs(s):
    return hexlify(s).decode("ascii").upper()


class progressbar:
    def __init__(self, prefix="", total=100, size=50, f=stdout):
        self.reset(prefix, total, size, f)

    def reset(self, prefix="", total=100, size=50, f=stdout):
        self.prefix = prefix
        self.total = total
        self.count = 0
        self.size = size
        self.file = f
        self.isatty = f.isatty()
        self.hash = -1

    def update(self, j):
        self.count += j
        x = int(self.size * self.count / self.total)
        per = int(self.count * 100 / self.total)
        if self.isatty:
            self.file.write("%s [%s%s] %i%%\r" %
                            (self.prefix, "#"*x, "."*(self.size-x), per))
        elif self.hash != x:
            if self.hash == -1:
                self.hash = x
                self.file.write("%s\n|%s" % (self.prefix, "#"*x))
            else:
                self.file.write("%s" % ("#"*(x-self.hash)))
                self.hash = x
        self.file.flush()

    def end(self):
        if not self.isatty:
            self.file.write("| 100%\n")
        else:
            self.file.write("\n")
        self.file.flush()


class RDA8910:
    def __init__(self):
        pass

    def DBG(self, s):
        if self.debug:
            print(s)

    def open(self):
        try:
            self.s = Serial(self.port, 921600)
        except serialutil.SerialException as ex:
            ERROR(ex)
        self.s.timeout = 1.0
    
    def close(self):
        try:
            self.s.close()
        except serialutil.SerialException as ex:
            ERROR(ex)

    def read(self, read_size):
        r = ""
        if read_size > 0:
            r = self.s.read(read_size)
            if self.debug:
                print("<-- {}".format(hexs(r)))
        return r

    def send(self, data):
        if len(data):
            if self.debug:
                print("--> {}".format(hexs(data)))
            self.s.write(data)


    def pdl1_send_cmd(self, cmd, subcmd, param1, param2):
        self.send(b'\xae' + pack('<I', cmd) + b'\xff\x00\x00')
        self.send(pack('<III', subcmd, param1, param2))


    def pdl1_check_resp(self):
        resp = self.read(12)
        return resp == b'\xae\x04\x00\x00\x00\xff\x00\x00\x00\x00\x00\x00'


    # FDL1 search device
    def pdl1_search_device(self):
        start_time = time()
        while True:
            self.pdl1_send_cmd(CMD_PDL1_SEARCH, 0, 0, 0)
            if self.pdl1_check_resp() == True:
                return True
            if ((time() - start_time) > 10):
                return False


    def fdl1_ready(self):
        self.pdl1_send_cmd(CMD_PDL1_SEARCH, 0x7, 0, 0)
        self.send(b'\x7e')  # FDL2 Start
        resp = self.read(42)
        return len(resp) == 42 and resp[0] == 0x7e and resp[1] == 0x00 and resp[2] == 0x81 and resp[len(resp) - 1] == 0x7e


    def fdl1_checksum(self, data):
        checksum = 0
        for i in range(0, len(data), 2):
            checksum += data[i] << 8
            checksum += data[i + 1]
        checksum = (checksum >> 16) + (checksum & 0xffff)
        checksum += (checksum >> 16)
        return (~checksum & 0xffff)


    def fdl1_hdlc_encode(self, data):
        dlen = len(data)
        i = 0
        while i < dlen:
            if data[i] == 0x7e:
                data = data[:i] + b'\x7d\x5e' + data[i + 1:]
                dlen = len(data)
            elif data[i] == 0x7d:
                data = data[:i] + b'\x7d\x5d' + data[i + 1:]
                dlen = len(data)
            i += 1
        return data


    def fdl1_send(self, cmd, data):
        fdl_cmd = pack('>HH', cmd, len(data)) + data
        checksum = pack('>H', self.fdl1_checksum(fdl_cmd))
        fdl_cmd = self.fdl1_hdlc_encode(fdl_cmd + checksum)
        self.send(b'\x7e' + fdl_cmd + b'\x7e')


    def fdl1_check_resp(self):
        resp = self.read(8)
        return resp == b'\x7e\x00\x80\x00\x00\xff\x7f\x7e'

    def search_port(self, timeout=15):
        start_time = time()
        while True:
            ports = list_ports.grep("0525:A4A7")
            for port in ports:
                if "SPRD" in port.description:
                    print("Found port %s" % port.description)
                    self.port = port.device
                    return True
            if time() - start_time > timeout:
                return False
            sleep(1)
        
    def connect(self, timeout=30):
        ASSERT(self.pdl1_search_device(), "Timeout")
    
    def fdl1_download(self):
        fdl1_sz = getsize(self.fdl1)
        self.pb = progressbar("Download FDL1", fdl1_sz)
        self.pb.update(0)
        # Start FDL1 Download
        self.pdl1_send_cmd(CMD_PDL1_DLFDL1, 0x4, int(self.fdl1_addr, 16), getsize(self.fdl1))
        self.send(bytes('PDL1', 'ascii') + b'\x00')
        ASSERT(self.pdl1_check_resp(), "PDL1 Start fail")

        fdl1 = open(self.fdl1, "rb")
        idx = 0
        while True:
            chunk = fdl1.read(0x800)
            if len(chunk) == 0:
                break
            self.pdl1_send_cmd(
                CMD_PDL1_WRDATA if len(chunk) == 0x800 else CMD_PDL1_WRDATA_LAST,
                0x5, idx, len(chunk)
            )
            self.send(chunk)
            ASSERT(self.pdl1_check_resp(), "FDL1 Download fail")
            idx = idx + 1
            self.pb.update(len(chunk))
        fdl1.close()
        self.pb.end()
        self.pdl1_send_cmd(CMD_PDL1_FINISH, 0x6, 0, 0)
        self.send(b'\x1c\x3c\x6e\x06')
        ASSERT(self.pdl1_check_resp(), "FDL1 Finish fail")
        ASSERT(self.fdl1_ready(), "FDL not ready")

    def fdl2_download(self):
        self.fdl1_send(CMD_FDL1_NOP, bytes())
        ASSERT(self.fdl1_check_resp(), "FDL start fail")

        self.fdl1_send(CMD_FDL1_SETBAUD, pack('>I', 115200))
        ASSERT(self.fdl1_check_resp(), "FDL change baud fail")

        self.fdl1_send(CMD_FDL1_NOP, bytes())
        ASSERT(self.fdl1_check_resp(), "FDL Change baud confirm fail")

        fdl2_sz = getsize(self.fdl2)
        self.fdl1_send(CMD_FDL1_WRSTART, pack('>II', int(self.fdl2_addr, 16), fdl2_sz))
        ASSERT(self.fdl1_check_resp(), "FDL Write FDL2 fail")

        self.pb.reset("Download FDL2", fdl2_sz)
        self.pb.update(0)
        fdl2 = open(self.fdl2, "rb")
        while True:
            chunk = fdl2.read(0x840)
            if len(chunk) == 0:
                break
            self.fdl1_send(CMD_FDL1_WRDATA, chunk)
            ASSERT(self.fdl1_check_resp(), "FDL2 Write failed")
            self.pb.update(len(chunk))
        fdl2.close()
        self.pb.end()

        self.fdl1_send(CMD_FDL1_WRFINISH, bytes())
        ASSERT(self.fdl1_check_resp(), "FDL2 write finish fail")

        self.fdl1_send(CMD_FDL1_EXEC, bytes())
        ASSERT(self.fdl1_check_resp(), "FDL2 execute fail")

    def app_download(self):
        app_sz = getsize(self.appimg)
        self.fdl1_send(CMD_FDL1_WRSTART, pack('>II', int(self.app_addr, 16), app_sz))
        ASSERT(self.fdl1_check_resp(), "FDL Write APP fail")

        self.pb.reset("Download APP ", app_sz)
        self.pb.update(0)
        app = open(self.appimg, "rb")
        while True:
            chunk = app.read(0x800)
            if len(chunk) == 0:
                break
            self.fdl1_send(CMD_FDL1_WRDATA, chunk)
            ASSERT(self.fdl1_check_resp(), "APP Write failed")
            self.pb.update(len(chunk))
        app.close()
        self.pb.end()

        self.fdl1_send(CMD_FDL1_WRFINISH, bytes())
        ASSERT(self.fdl1_check_resp(), "APP write finish fail")

    def finish(self):
        if self.no_reset:
            return
        print("Resetting device to normal\n")
        self.fdl1_send(CMD_FDL1_RESET, bytes())
        ASSERT(self.fdl1_check_resp(), "APP write finish fail")

    def upload_app(self):
        ASSERT(self.search_port(), "Unable to find device.\nPlease make sure device is in boot mode.")
        self.open()
        self.connect()
        self.fdl1_download()
        self.fdl2_download()
        self.app_download()
        self.finish()
        self.close()


def rda8910_flasher(opts):
    flasher = RDA8910()
    flasher.no_reset = opts.no_reset
    flasher.fdl1_addr, flasher.fdl1, flasher.fdl2_addr, flasher.fdl2, flasher.app_addr, flasher.appimg = opts.firmware
    flasher.debug = opts.debug
    return flasher
