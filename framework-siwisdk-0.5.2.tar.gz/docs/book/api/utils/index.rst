Utility APIs
============
