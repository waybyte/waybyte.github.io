Message Queue API
=================

API Reference
-------------

.. include:: /inc/msgq.inc

