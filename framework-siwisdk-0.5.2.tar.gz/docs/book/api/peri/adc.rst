Analog to Digital Converter
===========================

There are 6 10-bit analog channels available on SIWI GSM modules. Input voltage
range from 0-2.8v gives digial output of 0-1023 respectively.

.. include:: /inc/adc.inc

