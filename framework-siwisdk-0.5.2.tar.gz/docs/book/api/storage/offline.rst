Offline Data Storage API
========================

SDK provide simple APIs to manage data storage. The offline storage APIs can be
used to store data on storage media duing unavailability of network.

API Reference
-------------

.. include:: /inc/offlinelib.inc

