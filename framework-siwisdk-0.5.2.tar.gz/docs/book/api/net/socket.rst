RAW Socket API
==============

.. include:: /inc/sockets.inc

