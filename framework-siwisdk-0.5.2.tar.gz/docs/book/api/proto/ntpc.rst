NTP Client
==========

Library provide NTP client service which can be enabled during
system initialization. Once enabled service will automatically
take care of setting system time when device is ready and GPRS
service is active. The NTP sync interval is 60 minutes.

API Reference
-------------

.. include:: /inc/ntpc.inc
