DHT Sensor API
==============

DHT Temperature and Humidity sensor library optimized for GSM module.

.. include:: /inc/dht.inc

